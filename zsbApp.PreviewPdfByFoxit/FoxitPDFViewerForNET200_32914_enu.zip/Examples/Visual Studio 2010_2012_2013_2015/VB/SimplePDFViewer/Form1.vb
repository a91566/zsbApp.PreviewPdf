﻿Public Class Form1
    Inherits System.Windows.Forms.Form
    Public Sub New()
        InitializeComponent()
        ' In the form constructor do not use any Viewer methods (Open, Print etc.) that perform UI activities.
    End Sub

End Class
